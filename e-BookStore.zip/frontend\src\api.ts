export type Book = { id: string; title: string; author: string }

export async function fetchBooks(): Promise<Book[]> {
  const res = await fetch('/api/books')
  if (!res.ok) throw new Error('Failed to fetch books')
  return res.json()
}
