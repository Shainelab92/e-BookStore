import React, { useEffect, useState } from 'react'
import { fetchBooks } from './api'

type Book = {
  id: string
  title: string
  author: string
}

export default function App() {
  const [books, setBooks] = useState<Book[]>([])

  useEffect(() => {
    fetchBooks().then(setBooks).catch(console.error)
  }, [])

  return (
    <div style={{ padding: 20, fontFamily: 'sans-serif' }}>
      <h1>e-BookStore</h1>
      <ul>
        {books.map((b) => (
          <li key={b.id}>
            <strong>{b.title}</strong> — {b.author}
          </li>
        ))}
      </ul>
    </div>
  )
}
