import express from 'express'

const app = express()
const port = process.env.PORT ? Number(process.env.PORT) : 4000

app.use(express.json())

const books = [
  { id: '1', title: 'The Pragmatic Programmer', author: 'Andrew Hunt & David Thomas' },
  { id: '2', title: 'Clean Code', author: 'Robert C. Martin' },
  { id: '3', title: 'You Don\'t Know JS', author: 'Kyle Simpson' }
]

app.get('/api/books', (_req, res) => {
  res.json(books)
})

app.listen(port, () => {
  console.log(`Backend listening on http://localhost:${port}`)
})
